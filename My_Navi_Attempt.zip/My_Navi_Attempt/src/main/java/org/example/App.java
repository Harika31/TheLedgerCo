package org.example;

import org.example.Ledger.ReadInput;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class App 
{
    public static void main( String[] args ) throws FileNotFoundException, IOException
    {
        String filePath = new File("infile.txt").getAbsolutePath();
        File inputFile = new File(filePath);
        ReadInput.readInputData(inputFile);
    }
}
