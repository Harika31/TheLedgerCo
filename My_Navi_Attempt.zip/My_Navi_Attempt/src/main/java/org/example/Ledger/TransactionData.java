package org.example.Ledger;

public class TransactionData
{
    public enum Type
    {
        LOAN, PAYMENT, BALANCE
    }

    private Type type;
    private String bankName;
    private String borrowerName;
    private Long principalAmount;
    private Integer noOfYears;
    private Integer rateOfInterest;
    private Long amountToRepay;
    private Long emi;

    private Long emiNo;
    private Long lumpSum;

    public TransactionData(String type, String bankName, String borrowerName, Long principalAmount, Integer noOfYears, Integer rateOfInterest,
                           Long amountToRepay, Long emi) {
        this.type = Type.valueOf(type);
        this.bankName = bankName;
        this.borrowerName = borrowerName;
        this.principalAmount = principalAmount;
        this.noOfYears = noOfYears;
        this.rateOfInterest = rateOfInterest;
        this.amountToRepay = amountToRepay;
        this.emi = emi;
    }

    public TransactionData(String type, String bankName, String borrowerName, Long lumpSum, Long emiNo)
    {
        this.type = Type.valueOf(type);
        this.bankName = bankName;
        this.borrowerName = borrowerName;
        this.lumpSum = lumpSum;
        this.emiNo = emiNo;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBorrowerName() {
        return borrowerName;
    }

    public void setBorrowerName(String borrowerName) {
        this.borrowerName = borrowerName;
    }

    public Long getPrincipalAmount() {
        return principalAmount;
    }

    public void setPrincipalAmount(Long principalAmount) {
        this.principalAmount = principalAmount;
    }

    public Integer getNoOfYears() {
        return noOfYears;
    }

    public void setNoOfYears(Integer noOfYears) {
        this.noOfYears = noOfYears;
    }

    public Integer getRateOfInterest() {
        return rateOfInterest;
    }

    public void setRateOfInterest(Integer rateOfInterest) {
        this.rateOfInterest = rateOfInterest;
    }

    public Long getEmiNo() {
        return emiNo;
    }

    public void setEmiNo(Long emiNo) {
        this.emiNo = emiNo;
    }

    public Long getLumpSum() {
        return lumpSum;
    }

    public void setLumpSum(Long lumpSum) {
        this.lumpSum = lumpSum;
    }

    public Long getAmountToRepay() {
        return amountToRepay;
    }

    public void setAmountToRepay(Long amountToRepay) {
        this.amountToRepay = amountToRepay;
    }

    public Long getEmi() {
        return emi;
    }

    public void setEmi(Long emi) {
        this.emi = emi;
    }
}
