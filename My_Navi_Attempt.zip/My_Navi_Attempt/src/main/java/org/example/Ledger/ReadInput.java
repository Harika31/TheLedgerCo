package org.example.Ledger;

import java.io.*;
import java.util.*;

public class ReadInput
{

    public static void readInputData(File inputFile) throws IOException
    {
        List<String> outputData = new ArrayList<>();
        List<TransactionData> transactions = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        String inputLine = new String();
        EmiCalculations emiCalculations = new EmiCalculationsImpl();
        while((inputLine = reader.readLine()) != null)
        {
            String[] dataValues = inputLine.split(" ");
            switch (dataValues[0])
            {
                case "LOAN":
                    emiCalculations.addLoanTransactions(dataValues, transactions);
                    break;
                case "PAYMENT":
                    emiCalculations.addPaymentTransactions(dataValues, transactions);
                    break;
                case "BALANCE":
                    String output = emiCalculations.getBalanceOfAUser(dataValues, transactions);
                    outputData.add(output);
                    break;
            }
        }
        reader.close();
        for(String output : outputData)
        {
            System.out.println(output);
        }
    }
}
