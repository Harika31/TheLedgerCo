package org.example.Ledger;

import java.util.*;

public class EmiCalculationsImpl implements EmiCalculations
{
    @Override
    public void addLoanTransactions(String[] dataValues, List<TransactionData> transactions)
    {
        Long interest = Long.valueOf(dataValues[3])*Long.valueOf(dataValues[4])*Long.valueOf(dataValues[5])/100;
        Long totalAmount = Long.valueOf(dataValues[3]) + interest;
        Long emi = (long) Math.ceil((double)totalAmount/(double)(Integer.valueOf(dataValues[4])*12));
        transactions.add(new TransactionData(dataValues[0], dataValues[1], dataValues[2], Long.valueOf(dataValues[3]),
                Integer.valueOf(dataValues[4]), Integer.valueOf(dataValues[5]), totalAmount, emi));
        return;
    }

    @Override
    public void addPaymentTransactions(String[] dataValues, List<TransactionData> transactions)
    {
        transactions.add(new TransactionData(dataValues[0], dataValues[1], dataValues[2], Long.valueOf(dataValues[3]),
                Long.valueOf(dataValues[4])));
        return;
    }

    @Override
    public String getBalanceOfAUser(String[] dataValues, List<TransactionData> transactions)
    {
        TransactionData loan = getTransactionsDataOfAUser(transactions, "LOAN", dataValues[1], dataValues[2]).get(0);
        List<TransactionData> payments = getTransactionsDataOfAUser(transactions, "PAYMENT", dataValues[1], dataValues[2]);
        Long amountPaid = 0l; Long totalLumpSum = 0l;
        for(TransactionData data : payments)
        {
            if(data.getEmiNo() <= Integer.valueOf(dataValues[3]))
            {
                totalLumpSum += data.getLumpSum();
            }
        }
        Long paidAmount = Integer.valueOf(dataValues[3])*loan.getEmi() + totalLumpSum;
        Long remainingAmount = loan.getAmountToRepay() - paidAmount;
        Long noOfPendingTransactions = (long)(Math.ceil((double)remainingAmount/(double)loan.getEmi()));
        return dataValues[1] + " " + dataValues[2] + " " + paidAmount + " " + noOfPendingTransactions;
    }

    private List<TransactionData> getTransactionsDataOfAUser(List<TransactionData> list, String type, String bankName, String borrowerName)
    {
        List<TransactionData> response = new ArrayList<>();
        for(TransactionData data : list)
        {
            if(data.getBankName().equalsIgnoreCase(bankName) && data.getBorrowerName().equalsIgnoreCase(borrowerName)
            && data.getType().toString().equalsIgnoreCase(type))
            {
                response.add(data);
            }
        }
        return response;
    }
}
