package org.example.Ledger;

import java.util.List;

public interface EmiCalculations
{
    void addLoanTransactions(String[] dataValues, List<TransactionData> transactions);

    void addPaymentTransactions(String[] dataValues, List<TransactionData> transactions);

    String getBalanceOfAUser(String[] dataValues, List<TransactionData> transactions);
}
